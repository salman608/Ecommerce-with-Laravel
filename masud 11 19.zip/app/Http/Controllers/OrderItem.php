<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class OrderItem extends Controller
{
    //
}
