
<?php $__env->startSection('brand'); ?> active <?php $__env->stopSection(); ?>
<?php $__env->startSection('admin_content'); ?>

<div class="sl-mainpanel">
  <nav class="breadcrumb sl-breadcrumb">
    <a class="breadcrumb-item" href="index.html">Brand</a>
    <span class="breadcrumb-item active">Dashboard</span>
  </nav>

  <div class="sl-pagebody">
    <div class="row">
      <div class="col-md-8">
        <div class="card pd-20 pd-sm-40">

          <div class="table-wrapper">
            <table id="datatable1" class="table display responsive nowrap">
              <thead>
                <tr>
                  <th class="wd-15p">Sl</th>
                  <th class="wd-15p">Brand Name</th>
                  <th class="wd-20p">Status</th>
                  <th class="wd-15p">Action</th>

                </tr>
              </thead>
              <tbody>
                <?php
                $i=1;
                ?>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                  <td><?php echo e($i++); ?></td>
                  <td><?php echo e($brand->brand_name); ?></td>
                  <td>
                       <?php if($brand->brand_status == 1): ?>
                       <span class="badge badge-success">Active</span>
                       <?php else: ?>
                       <span class="badge badge-warning">Inactive</span>
                       <?php endif; ?>
                  </td>
                  <td>
                    <a href="<?php echo e(route('edit.brand',$brand->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-pencil"></i> </a>
                    <a href="<?php echo e(route('delete.brand',$brand->id)); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> </a>
                    <?php if($brand->brand_status==1): ?>
                    <a href="<?php echo e(route('inactive.brand',$brand->id)); ?>" class="btn btn-warning btn-sm"><i class="fa fa-arrow-down"></i> </a>
                    <?php else: ?>
                    <a href="<?php echo e(route('active.brand',$brand->id)); ?>" class="btn btn-success btn-sm"><i class="fa fa-arrow-up"></i> </a>
                    <?php endif; ?>
                  </td>
                </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div><!-- table-wrapper -->
        </div><!-- card -->
      </div>

      <div class="col-md-4">
          <div class="card">
              <div class="card-header bg-warning text-white">Add Brand
              </div>

              <div class="card-body">
                  

            <?php if(session('success')): ?>
              <div class="alert alert-success alert-dismissible fade show" role="alert">
              <strong><?php echo e(session('success')); ?></strong>
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <?php endif; ?>

                  <form action="<?php echo e(route('store.brand')); ?>" method="POST">
                      <?php echo csrf_field(); ?>
                      <div class="form-group">
                        <label for="exampleInputEmail1">Add Brand</label>
                        <input type="text" name="brand_name" class="form-control <?php $__errorArgs = ['brand_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Brand Name">

                        <?php $__errorArgs = ['brand_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                      </div>

                      <button type="submit" class="btn btn-primary">Add Brand</button>
                    </form>




              </div>
          </div>

      </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecom\resources\views/admin/brand/index.blade.php ENDPATH**/ ?>