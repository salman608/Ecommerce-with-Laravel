
<?php $__env->startSection('product'); ?> active show-sub <?php $__env->stopSection(); ?>
<?php $__env->startSection('menage-product'); ?> active  <?php $__env->stopSection(); ?>
<?php $__env->startSection('admin_content'); ?>

<div class="sl-mainpanel">
  <nav class="breadcrumb sl-breadcrumb">
    <a class="breadcrumb-item" href="index.html">Dashboard</a>
    <span class="breadcrumb-item active">Menage Products</span>
  </nav>

  <div class="sl-pagebody">
    <div class="row">
      <div class="col-md-12">
        <div class="card pd-20 pd-sm-40">
          <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('success')); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <?php endif; ?>

              <?php if(session('delete')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(session('delete')); ?></strong>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <?php endif; ?>
          <h3 class="card-body-title">Product List</h3>

          <div class="table-wrapper">
            <table id="datatable1" class="table display responsive nowrap">
              <thead>
                <tr>
                  <th class="wd-15p">Image</th>
                  <th class="wd-15p">Product Name</th>
                  <th class="wd-20p">Product Qunt</th>
                  <th class="wd-20p">Pd Code</th>
                  <th class="wd-20p">Price</th>
                  <th class="wd-20p">Category</th>
                  <th class="wd-20p">Status</th>
                  <th class="wd-15p">Action</th>

                </tr>
              </thead>
              <tbody>
                <?php
                $i=1;
                ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                  <td>
                    <img src="<?php echo e(asset($product->image_one)); ?>" width="50px" height="50px" alt="">
                  </td>
                  <td><?php echo e($product->product_name); ?></td>
                  <td><?php echo e($product->product_quantity); ?></td>
                  <td><?php echo e($product->product_code); ?></td>
                  <td><?php echo e($product->product_price); ?></td>
                  <td><?php echo e($product->category->category_name); ?></td>
                  <td>
                       <?php if($product->product_status == 1): ?>
                       <span class="badge badge-success">Active</span>
                       <?php else: ?>
                       <span class="badge badge-warning">Inactive</span>
                       <?php endif; ?>
                  </td>
                  <td>
                    <a href="<?php echo e(route('edit.product',$product->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-pencil"></i> </a>
                    <a href="<?php echo e(route('delete.product',$product->id)); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> </a>
                    <?php if($product->product_status==1): ?>
                    <a href="<?php echo e(route('inactive.product',$product->id)); ?>" class="btn btn-success btn-sm"><i class="fa fa-arrow-up"></i> </a>

                    <?php else: ?>
                    <a href="<?php echo e(route('active.product',$product->id)); ?>" class="btn btn-warning btn-sm"><i class="fa fa-arrow-down"></i> </a>
                    <?php endif; ?>
                  </td>
                </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div><!-- table-wrapper -->
        </div><!-- card -->
      </div>


        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecommerce\resources\views/admin/product/menage.blade.php ENDPATH**/ ?>